//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "similarity.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "SDL_replist"
#pragma resource "*.dfm"
TFrame2 *Frame2;
//---------------------------------------------------------------------------
__fastcall TFrame2::TFrame2(TComponent* Owner)
	: TFrame(Owner)
{
}
//---------------------------------------------------------------------------
